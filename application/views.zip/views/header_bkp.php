<?Php
$pagename = $this->uri->segment('1');
?>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="Sinaztech provides best in class solutions to small and large enterprises through EPM, business analytics, CRM, big data analysis, infrastructure and upgrade services. " />
    <meta name="keywords" content="Business Intelligence,Business Intelligence and Analytics,Business Intelligence Services,Business Intelligence Solutions,Consultant Company,Oracle Business Intelligence,Oracle Business Intelligence Foundation Suite,Oracle Consulting Services,Business Intelligence Tools,Business Intelligence Iools and Techniques"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> SINAZ Techsol Pvt Ltd</title>
    <!-- favicon links -->
    <link rel="shortcut icon" type="image/ico" href="<?php echo base_url(); ?>asserts/css/favicon.ico" />
    <link rel="icon" type="image/ico" href="<?php echo base_url(); ?>css/favicon.ico" />
    <!--Google web fonts-->
    <link href='https://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

    <!-- main css -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>asserts/css/main.css" media="screen"/>
    <link rel="stylesheet" href="<?php echo base_url(); ?>asserts/css/color/color3.css" id='color3' media="screen"/>

    <!--page title-->
    <title> SINAZ Techsol Pvt Ltd</title>
</head>
<body>
    <!--Pre loader start-->
    <div id="preloader">
        <div id="status"><img src="<?php echo base_url(); ?>asserts/images/common/loader.gif" id="preloader_image" width="36" height="36" alt="loading image" style="color:#E54242"/></div>
    </div>    
    
    <!--pre loader end--> 
    <!-- color picker start -->

    <!-- color picker end --> 
    <!--header start-->
    <header id="hs_header" style="background-color: #2B2C7A;
            max-height: 32px;">
        <div class="container" >
            <div class="row" >
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clearfix menu_section">

                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="padding-left:0px;">

                        <div id="hs_logo" > <a href="<?php echo base_url(); ?>index"> <img src="<?php echo base_url(); ?>asserts/images/header/logo.gif" alt=""> </a> </div>
                        <!-- #logo --> 
                    </div>

                    <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 topmenuimg" >
                        <button type="button" class="hs_nav_toggle navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">Menu<i class="fa fa-bars"></i></button>
                        <nav class="responsivenav">
                            <ul class="hs_menu collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <li class="topmenu"><a href="<?php echo base_url(); ?>index"><span  class="spanmenu" id="home">Home</span></a></li>
                                <li class="topmenu"><a href="<?php echo base_url(); ?>services"><span  class="spanmenu" id="services">Services</span></a></li>
                                <li class="topmenu"><a href="<?php echo base_url(); ?>products"><span  class="spanmenu" id="products">Products</span></a></li>
                                <li class="topmenu"><a href="<?php echo base_url(); ?>careers"><span class="spanmenu" id="careers">Careers</span></a></li>
                                <li class="topmenu"><a href="<?php echo base_url(); ?>contact_us"><span  class="spanmenu" id="contact">Contact Us</span></a></li>
                                <div class="clearfix"></div>
                            </ul>                            
                        </nav>
                    </div>               
                </div>
                <!-- .col-md-12 --> 
            </div>
            <!-- .row --> 
        </div>

        <!-- .container --> 

    </header>
