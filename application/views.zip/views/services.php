<!DOCTYPE html>
<html lang="en">
    <script type="text/javascript" src="http://srvmedia.com/demo/acclivity/asserts/js/jquery-1.11.0.min.js"></script> 
    <script>
        $("#services").addClass("active");
    </script>
    <!--header end--> 
    <!--slider start-->

    <div  data-ride="carousel"> 
        <!-- Indicators -->


        <img class="img_width" src="<?php echo base_url(); ?>asserts/images/services/serbanner.jpg">
        <div class="hs_page_title">
            <div class="container">
                <h3>Services</h3>
                <ul>
                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                    <li><a href="#">Services</a></li>
                </ul>
            </div>
        </div>
        <div class="container"> 
            <!--service start-->

            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <!--<h2 class="hs_heading">Services</h2>-->
                    <div class="row hs_how_we_are ">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="hs_how_we_are_text newd">
                                <p>Sinaz Tech Sol diverse Services help companies enhance their performance in today's technological world. Our state of the art facilities include Work Force Solutions, Managed Services, Project Solutions and comprehensive customer support. We Provide a range of advanced data-driven solutions, services and products for the technological age.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <h4 class="hs_heading"> </h4>
                    <div class="releted_post">
                        <div id="releted_post_slider" class="owl-carousel owl-theme">
                            <div class="releted_post_slider_item">
                                <div class="row">

                                    <div class="col-lg-12"> <img class="img_width" alt="Image description" src="<?php echo base_url(); ?>asserts/images/services/services_workfrocesolution.jpg" />
                                        <div class="releted_post_detail">
                                            <h4> Work Force Solutions</h4>

                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> IT Staff Augmentation.
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Permanent Recruitment.
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Hire, Train &amp; Deploy.
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Borderless Talent Solutions.
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Executive Hiring.
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Variabilization Solutions.
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="releted_post_slider_item">
                                <div class="row">

                                    <div class="col-lg-12"><img class="img_width" alt="Image description" src="<?php echo base_url(); ?>asserts/images/services/services_mangedservice.jpg" />
                                        <div class="releted_post_detail">
                                            <h4>Managed Services</h4>

                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Application Management &amp; Maintenance 
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Data Centre Services 
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Telecom Business Applications 
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Infrastructure Managed Services 
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> End User Support Services 
                                            <br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="releted_post_slider_item">
                                <div class="row">

                                    <div class="col-lg-12"> <img class="img_width" alt="Image description" src="<?php echo base_url(); ?>asserts/images/services/services_project_solution.jpg" />
                                        <div class="releted_post_detail">
                                            <h4> Project Solutions</h4>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Application Management &amp; Maintenance
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Data Centre Services
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Telecom Business Applications
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> Infrastructure Managed Services
                                            <br>
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i> End User Support Services
                                            <br>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="customNavigation text-right"> <a class="btn_prev prev"><i class="fa fa-chevron-left"></i></a> <a class="btn_next next"><i class="fa fa-chevron-right"></i></a> </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hs_margin_40"></div>
    </div>
    <!--main js file end-->
</body>
</html>