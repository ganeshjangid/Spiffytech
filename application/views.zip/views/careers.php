<!DOCTYPE html>
<html lang="en">
    <script type="text/javascript" src="http://srvmedia.com/demo/acclivity/asserts/js/jquery-1.11.0.min.js"></script> 
    <script>
        $("#careers").addClass("active");
    </script>
    <!--header end--> 
    <!--slider start-->

    <div data-ride="carousel"> 
        <!-- Indicators -->

        <img class="img_width" src="<?php echo base_url(); ?>asserts/images/career/Career.jpg">
        <div class="hs_page_title">
            <div class="container">
                <h3>Careers</h3>
                <ul>
                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                    <li><a href="#">Careers</a></li>
                </ul>
            </div>
        </div>
        <div class="container"> 
            <!--service start-->
            <div class="row">
                <h2 class="hs_heading col-lg-12"></h2>

                <div class="col-lg-6">
                    <div class="row">
                        <div class="col-lg-12">

                            <blockquote class="margin_quote">
                                <p>The Best way to predict the future is to Create it.&nbsp;</p>
                                <footer>Abraham Lincon</footer>
                            </blockquote>
                            <blockquote class="blockquote-reverse">
                                <p>"If you don't wake up in the morning excited to pick up where you left your&nbsp;
                                    work yesterday, you haven't found your calling yet".&nbsp;</p>
                                <footer>- Mike Wallace</footer>
                            </blockquote>
                            <p style="font-size: 18px;">For career opportunities please contact us at careers@sinaztechsol.com.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <p><img class="img_width" alt="Image description" src="<?php echo base_url(); ?>asserts/images/career/careers_new_people.png" /></p>
                </div>
            </div>    
        </div>
    </div>
    <!--main js file end-->
</body>
</html>