<footer id="hs_footer">
    <div class="container">
        <div class="hs_footer_content"><br>
            <div class="row">
                <div class="col-xs-10 col-sm-10 col-md-10 foot-widget-bottom margin_div">
                    <a href="<?php echo base_url(); ?>index">Home</a> |
                    <a href="<?php echo base_url(); ?>services">Services</a> |
                    <a href="<?php echo base_url(); ?>products">Products</a> |
                    <a href="<?php echo base_url(); ?>contact_us">Contact Us</a> 
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-lg-12"> 
                    <div class="col-lg-10 col-md-10 col-sm-10"> &#169;&nbsp; SINAZ Techsol Pvt Ltd. All Rights Reserved. Designed by <a href="http://srvmedia.com" target="_blank">SRV Media Pvt. Ltd</a></div>

                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="hs_social">
                            <ul>
                                <li><a href=""><i class="fa fa-facebook" id="fb"></i></a></li>
                                <li><a href=""><i class="fa fa-twitter" id="twitter"></i></a></li>
                                <li><a href=""><i class="fa fa-google-plus" id="google"></i></a></li>
                            </ul>
                        </div></div>
                </div>

            </div>
        </div><br>
        </footer>

        <!--main js file start--> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/jquery-1.11.0.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/bootstrap.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/owl.carousel.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/jquery.bxslider.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/jquery.mixitup.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/smoothscroll.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/single-0.1.0.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/custom.js"></script> 

        <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-76816738-1', 'auto');
            ga('send', 'pageview');

        </script>
        <script type="text/javascript">
        $('#slider_section').carousel(function(){
            interval:10000
        });
        </script>

