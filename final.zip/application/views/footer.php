<footer id="hs_footer">
    <div class="container">
        <div class="hs_footer_content"><br>
            <div class="row">
                <div class="col-xs-10 col-sm-10 col-md-10 foot-widget-bottom">
                    <a href="<?php echo base_url(); ?>index">Home</a> |
                    <a href="<?php echo base_url(); ?>overview">Company Insight</a> |
                    <a href="<?php echo base_url(); ?>services">Services & Platform</a> |
                    <!--<a href="<?php echo base_url(); ?>products">Products</a> |-->
                    <a href="<?php echo base_url(); ?>cots">COTS</a> | 
                    <a href="<?php echo base_url(); ?>coe">COE</a> |
                    <a href="<?php echo base_url(); ?>casestudies">Case Studies</a> |
                    <a href="<?php echo base_url(); ?>whysinaz">Why Spiffy Tech</a> |
                    <a href="<?php echo base_url(); ?>careers">Careers</a> |
                    <a href="<?php echo base_url(); ?>contactus">Contact Us</a> 
                </div>

                    <div class="col-lg-2 col-md-6 col-sm-6">
                        <div class="hs_social">
                            <ul>
                                <li><a href=""><i class="fa fa-facebook" id="fb"></i></a></li>
                                <li><a href=""><i class="fa fa-twitter" id="twitter"></i></a></li>
                                <li><a href=""><i class="fa fa-google-plus" id="google"></i></a></li>
                            </ul>
                        </div></div>

            </div>
            <br>
            <div class="row">
                <div class="col-lg-12"> 
                    <div class="col-lg-6 col-md-12 col-sm-12"> &#169;&nbsp; Spiffy Tech. All Rights Reserved.</div>

                    <div class="col-lg-6 col-md-12 col-sm-12" style="    text-align: right;"> Designed by <a href="http://www.srvmedia.com/" target="_blank" style="color:#ababab">SRV Media </a> and Developed by <a href="http://easebuzz.in/" target="_blank" style="color:#ababab"> Easebuzz </a>


</div>

                
                </div>

            </div>
        </div><br>
        </footer>

        <!--main js file start--> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/jquery-1.11.0.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/bootstrap.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/owl.carousel.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/jquery.bxslider.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/jquery.mixitup.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/smoothscroll.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/single-0.1.0.min.js"></script> 
        <script type="text/javascript" src="<?php echo base_url(); ?>asserts/js/custom.js"></script> 

        <script>
            (function (i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function () {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                        m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-76816738-1', 'auto');
            ga('send', 'pageview');

        </script>
        <script type="text/javascript">
        $('#slider_section').carousel(function(){
            interval:10000
        });
        </script>

